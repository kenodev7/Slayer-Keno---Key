const express = require('express');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT) || 8000;

const DATA_DIR = path.join(__dirname, 'data');
const KEYS_FILE = path.join(DATA_DIR, 'keys.json');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const WRONG_V4_HASH = '240be518fabd2724ddb6f04eebf2b5f569c039bcc0313e34c4e15354b49cdfab';

function sha256(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function ensureDataFiles() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(KEYS_FILE)) {
    fs.writeFileSync(KEYS_FILE, '[]', 'utf8');
  }

  if (!fs.existsSync(CONFIG_FILE)) {
    fs.writeFileSync(
      CONFIG_FILE,
      JSON.stringify(
        {
          adminUser: 'admin',
          adminPassHash: sha256('admin123'),
          panelTitle: 'SLAYER KEY PANEL',
          sessionSecret: crypto.randomBytes(32).toString('hex'),
          keyPrefix: 'SLAYER',
          heroImage: null,
          heroMode: 'contain'
        },
        null,
        2
      ),
      'utf8'
    );
  }
}

ensureDataFiles();

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

function safeText(value, fallback = '') {
  if (typeof value !== 'string') return fallback;
  return value.trim();
}

function normalizeKey(value) {
  return String(value || '').trim().toUpperCase();
}

function readConfig() {
  const config = readJson(CONFIG_FILE, {});
  let changed = false;

  if (!config.adminUser) {
    config.adminUser = 'admin';
    changed = true;
  }

  if (!config.adminPassHash || config.adminPassHash === WRONG_V4_HASH) {
    config.adminPassHash = sha256('admin123');
    changed = true;
  }

  if (!config.sessionSecret) {
    config.sessionSecret = crypto.randomBytes(32).toString('hex');
    changed = true;
  }

  if (!config.panelTitle) {
    config.panelTitle = 'SLAYER KEY PANEL';
    changed = true;
  }

  if (!config.keyPrefix) {
    config.keyPrefix = 'SLAYER';
    changed = true;
  }

  if (!Object.prototype.hasOwnProperty.call(config, 'heroImage')) {
    config.heroImage = null;
    changed = true;
  }

  if (!config.heroMode) {
    config.heroMode = 'contain';
    changed = true;
  }

  if (changed) {
    writeJson(CONFIG_FILE, config);
  }

  return config;
}

function getSessionSecret() {
  return readConfig().sessionSecret;
}

function readKeys() {
  const list = readJson(KEYS_FILE, []);
  return Array.isArray(list) ? list : [];
}

function saveKeys(keys) {
  writeJson(KEYS_FILE, keys);
}

app.use(express.json({ limit: '12mb' }));
app.use(express.urlencoded({ extended: true, limit: '12mb' }));
app.use(
  session({
    secret: getSessionSecret(),
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 1000 * 60 * 60 * 12
    }
  })
);
app.use(express.static(path.join(__dirname, 'public')));

function requireLogin(req, res, next) {
  if (!req.session?.loggedIn) {
    return res.status(401).json({ error: 'Não autorizado' });
  }
  next();
}

function addDays(baseDate, days) {
  const date = new Date(baseDate);
  date.setDate(date.getDate() + Number(days));
  return date;
}

function diffDays(expiresAt) {
  const now = new Date();
  const end = new Date(expiresAt);
  const diffMs = end.getTime() - now.getTime();
  if (Number.isNaN(diffMs) || diffMs <= 0) return 0;
  return Math.ceil(diffMs / 86400000);
}

function isExpired(expiresAt) {
  return new Date() > new Date(expiresAt);
}

function formatDate(date) {
  return new Date(date).toLocaleString('pt-BR');
}

function nextKeyNumber(keys) {
  let max = 0;

  for (const item of keys) {
    const number = Number(item?.serial || String(item?.key || '').split('-')[1]);
    if (!Number.isNaN(number) && number > max) {
      max = number;
    }
  }

  return max + 1;
}

function createKeyString(keys, prefix) {
  const serial = nextKeyNumber(keys);
  return {
    serial,
    key: `${prefix}-${String(serial).padStart(6, '0')}`
  };
}

function publicKeyView(item) {
  const expired = isExpired(item.expiresAt);
  const status = !item.active ? 'disabled' : expired ? 'expired' : 'active';

  return {
    key: item.key,
    serial: item.serial,
    owner: item.owner || '',
    note: item.note || '',
    createdAt: item.createdAt,
    createdAtLabel: formatDate(item.createdAt),
    expiresAt: item.expiresAt,
    expiresAtLabel: formatDate(item.expiresAt),
    daysRemaining: diffDays(item.expiresAt),
    active: Boolean(item.active),
    expired,
    status,
    deviceBound: Boolean(item.deviceHash),
    deviceName: item.deviceName || null,
    firstValidationAt: item.firstValidationAt || null,
    firstValidationAtLabel: item.firstValidationAt ? formatDate(item.firstValidationAt) : '-',
    lastValidationAt: item.lastValidationAt || null,
    lastValidationAtLabel: item.lastValidationAt ? formatDate(item.lastValidationAt) : '-',
    validationCount: Number(item.validationCount || 0)
  };
}

function getStats(keys) {
  const views = keys.map(publicKeyView);
  return {
    total: views.length,
    active: views.filter((item) => item.status === 'active').length,
    disabled: views.filter((item) => item.status === 'disabled').length,
    expired: views.filter((item) => item.status === 'expired').length,
    bound: views.filter((item) => item.deviceBound).length
  };
}

function resolveValidationPayload(req) {
  const body = req.body || {};
  return {
    key: normalizeKey(body.key || req.params.key || req.query.key || req.headers['x-license-key']),
    deviceId: safeText(body.deviceId || req.query.deviceId || req.headers['x-device-id']),
    deviceName: safeText(body.deviceName || req.query.deviceName || req.headers['x-device-name'] || req.headers['user-agent'], 'Dispositivo 1')
  };
}

function findKey(keys, key) {
  return keys.find((entry) => entry.key === normalizeKey(key));
}

function validateKeyRequest(req, res) {
  const { key, deviceId, deviceName } = resolveValidationPayload(req);
  const keys = readKeys();
  const item = keys.find((entry) => entry.key === key);

  if (!key || !deviceId) {
    return res.status(400).json({ valid: false, error: 'Envie a key e o deviceId' });
  }

  if (!item) {
    return res.status(404).json({ valid: false, error: 'Key não encontrada' });
  }

  if (!item.active) {
    return res.status(403).json({ valid: false, error: 'Key desativada', data: publicKeyView(item) });
  }

  if (isExpired(item.expiresAt)) {
    return res.status(403).json({ valid: false, error: 'Key expirada', data: publicKeyView(item) });
  }

  const incomingHash = sha256(deviceId);
  const now = new Date().toISOString();

  if (!item.deviceHash) {
    item.deviceHash = incomingHash;
    item.deviceName = safeText(deviceName, 'Dispositivo 1');
    item.firstValidationAt = now;
    item.lastValidationAt = now;
    item.validationCount = Number(item.validationCount || 0) + 1;
    saveKeys(keys);

    return res.json({
      valid: true,
      firstBind: true,
      message: 'Key validada e presa neste aparelho',
      data: publicKeyView(item)
    });
  }

  if (item.deviceHash !== incomingHash) {
    return res.status(403).json({
      valid: false,
      error: 'Essa key já está presa em outro aparelho',
      data: publicKeyView(item)
    });
  }

  item.lastValidationAt = now;
  item.validationCount = Number(item.validationCount || 0) + 1;
  saveKeys(keys);

  return res.json({
    valid: true,
    firstBind: false,
    message: 'Key válida neste aparelho',
    data: publicKeyView(item)
  });
}

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', online: true, port: PORT });
});

app.get('/api/config/public', (req, res) => {
  const config = readConfig();
  res.json({
    panelTitle: config.panelTitle,
    keyPrefix: config.keyPrefix,
    heroImage: config.heroImage || null,
    heroMode: config.heroMode || 'contain'
  });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const config = readConfig();

  if (safeText(username) === config.adminUser && sha256(password || '') === config.adminPassHash) {
    req.session.loggedIn = true;
    req.session.username = config.adminUser;
    return res.json({
      success: true,
      user: config.adminUser,
      panelTitle: config.panelTitle,
      heroImage: config.heroImage || null,
      heroMode: config.heroMode || 'contain'
    });
  }

  return res.status(401).json({ error: 'Usuário ou senha inválidos' });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

app.get('/api/session', (req, res) => {
  const config = readConfig();
  res.json({
    loggedIn: Boolean(req.session?.loggedIn),
    user: req.session?.username || null,
    panelTitle: config.panelTitle,
    keyPrefix: config.keyPrefix,
    heroImage: config.heroImage || null,
    heroMode: config.heroMode || 'contain'
  });
});

app.get('/api/dashboard', requireLogin, (req, res) => {
  const keys = readKeys();
  res.json({
    stats: getStats(keys),
    keys: keys.map(publicKeyView).reverse()
  });
});

app.post('/api/config/update', requireLogin, (req, res) => {
  const config = readConfig();
  const panelTitle = safeText(req.body?.panelTitle, config.panelTitle) || 'SLAYER KEY PANEL';
  const heroMode = safeText(req.body?.heroMode, config.heroMode || 'contain');
  const heroImage = req.body?.heroImage;
  const removeHero = Boolean(req.body?.removeHero);

  config.panelTitle = panelTitle;
  config.heroMode = heroMode === 'cover' ? 'cover' : 'contain';

  if (removeHero) {
    config.heroImage = null;
  } else if (typeof heroImage === 'string' && heroImage.startsWith('data:image/')) {
    const sizeBytes = Buffer.byteLength(heroImage, 'utf8');
    if (sizeBytes > 6 * 1024 * 1024) {
      return res.status(400).json({ error: 'Imagem muito grande' });
    }
    config.heroImage = heroImage;
  }

  writeJson(CONFIG_FILE, config);
  return res.json({
    success: true,
    message: 'Visual salvo',
    data: {
      panelTitle: config.panelTitle,
      keyPrefix: config.keyPrefix,
      heroImage: config.heroImage,
      heroMode: config.heroMode
    }
  });
});

app.post('/api/keys/create', requireLogin, (req, res) => {
  const { days, owner, note } = req.body || {};
  const totalDays = Number(days);

  if (!Number.isInteger(totalDays) || totalDays <= 0) {
    return res.status(400).json({ error: 'Dias inválidos' });
  }

  const config = readConfig();
  const keys = readKeys();
  const created = createKeyString(keys, normalizeKey(config.keyPrefix || 'SLAYER'));
  const now = new Date();

  const item = {
    serial: created.serial,
    key: created.key,
    owner: safeText(owner),
    note: safeText(note),
    createdAt: now.toISOString(),
    expiresAt: addDays(now, totalDays).toISOString(),
    active: true,
    deviceHash: null,
    deviceName: null,
    firstValidationAt: null,
    lastValidationAt: null,
    validationCount: 0
  };

  keys.push(item);
  saveKeys(keys);

  return res.json({ success: true, message: 'Key criada com sucesso', data: publicKeyView(item) });
});

app.post('/api/keys/validate', validateKeyRequest);
app.get('/api/keys/validate/:key', validateKeyRequest);

app.post('/api/keys/enable', requireLogin, (req, res) => {
  const keys = readKeys();
  const item = findKey(keys, req.body?.key);
  if (!item) return res.status(404).json({ error: 'Key não encontrada' });
  item.active = true;
  saveKeys(keys);
  return res.json({ success: true, message: 'Key ativada', data: publicKeyView(item) });
});

app.post('/api/keys/disable', requireLogin, (req, res) => {
  const keys = readKeys();
  const item = findKey(keys, req.body?.key);
  if (!item) return res.status(404).json({ error: 'Key não encontrada' });
  item.active = false;
  saveKeys(keys);
  return res.json({ success: true, message: 'Key desativada', data: publicKeyView(item) });
});

app.post('/api/keys/reset-device', requireLogin, (req, res) => {
  const keys = readKeys();
  const item = findKey(keys, req.body?.key);
  if (!item) return res.status(404).json({ error: 'Key não encontrada' });
  item.deviceHash = null;
  item.deviceName = null;
  item.firstValidationAt = null;
  item.lastValidationAt = null;
  item.validationCount = 0;
  saveKeys(keys);
  return res.json({ success: true, message: 'Aparelho removido da key', data: publicKeyView(item) });
});

app.post('/api/keys/extend', requireLogin, (req, res) => {
  const keys = readKeys();
  const item = findKey(keys, req.body?.key);
  const days = Number(req.body?.days);
  if (!item) return res.status(404).json({ error: 'Key não encontrada' });
  if (!Number.isInteger(days) || days <= 0) return res.status(400).json({ error: 'Dias inválidos' });
  const base = isExpired(item.expiresAt) ? new Date() : new Date(item.expiresAt);
  item.expiresAt = addDays(base, days).toISOString();
  saveKeys(keys);
  return res.json({ success: true, message: 'Validade aumentada', data: publicKeyView(item) });
});

app.post('/api/keys/update-owner', requireLogin, (req, res) => {
  const keys = readKeys();
  const item = findKey(keys, req.body?.key);
  if (!item) return res.status(404).json({ error: 'Key não encontrada' });
  item.owner = safeText(req.body?.owner);
  item.note = safeText(req.body?.note);
  saveKeys(keys);
  return res.json({ success: true, message: 'Dados salvos', data: publicKeyView(item) });
});

app.post('/api/keys/delete', requireLogin, (req, res) => {
  const keys = readKeys();
  const key = normalizeKey(req.body?.key);
  const index = keys.findIndex((entry) => entry.key === key);
  if (index === -1) return res.status(404).json({ error: 'Key não encontrada' });
  const [removed] = keys.splice(index, 1);
  saveKeys(keys);
  return res.json({ success: true, message: 'Key removida', data: publicKeyView(removed) });
});

app.get('/api', (req, res) => {
  res.json({
    online: true,
    message: 'SLAYER KEY API ONLINE',
    endpoints: {
      public: [
        'POST /api/login',
        'GET /api/session',
        'POST /api/keys/validate',
        'GET /api/keys/validate/:key?deviceId=SEU_ID&deviceName=SEU_NOME',
        'Headers: x-license-key, x-device-id, x-device-name'
      ],
      panel: [
        'GET /api/dashboard',
        'POST /api/keys/create',
        'POST /api/keys/enable',
        'POST /api/keys/disable',
        'POST /api/keys/reset-device',
        'POST /api/keys/extend',
        'POST /api/keys/update-owner',
        'POST /api/keys/delete',
        'POST /api/config/update'
      ]
    }
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Rodando em http://127.0.0.1:${PORT}`);
});
