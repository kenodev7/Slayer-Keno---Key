const state = {
  keys: [],
  user: null,
  panelTitle: 'SLAYER KEY PANEL',
  heroImage: null,
  heroMode: 'contain',
  heroFileData: null
};

const loginView = document.getElementById('loginView');
const appView = document.getElementById('appView');
const loginForm = document.getElementById('loginForm');
const loginMessage = document.getElementById('loginMessage');
const createMessage = document.getElementById('createMessage');
const validateMessage = document.getElementById('validateMessage');
const heroMessage = document.getElementById('heroMessage');
const panelTitle = document.getElementById('panelTitle');
const panelTitleInside = document.getElementById('panelTitleInside');
const welcomeUser = document.getElementById('welcomeUser');
const keysList = document.getElementById('keysList');
const searchInput = document.getElementById('searchInput');
const modal = document.getElementById('modal');
const modalForm = document.getElementById('modalForm');
const modalTitle = document.getElementById('modalTitle');
const toast = document.getElementById('toast');
const panelTitleInput = document.getElementById('panelTitleInput');
const heroModeInput = document.getElementById('heroModeInput');
const heroFileInput = document.getElementById('heroFileInput');
const focusPhotoBtn = document.getElementById('focusPhotoBtn');
const heroPanel = document.getElementById('heroPanel');

const loginMedia = {
  shell: document.getElementById('heroShell'),
  bg: document.getElementById('heroBg'),
  main: document.getElementById('heroImage')
};

const panelMedia = {
  shell: document.getElementById('panelHeroShell'),
  bg: document.getElementById('panelHeroBg'),
  main: document.getElementById('panelHeroImage')
};

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || 'Erro na requisição');
  }
  return data;
}

function escapeHtml(text) {
  return String(text || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function setFeedback(element, message, type = '') {
  element.textContent = message || '';
  element.className = 'feedback' + (type ? ` ${type}` : '');
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.add('hidden'), 2200);
}

function setTitle(title) {
  state.panelTitle = title || 'SLAYER KEY PANEL';
  panelTitle.textContent = state.panelTitle;
  panelTitleInside.textContent = state.panelTitle;
  panelTitleInput.value = state.panelTitle;
  document.title = state.panelTitle;
}

function applyMedia(target, image, mode = 'contain') {
  const hasImage = Boolean(image);
  target.shell.dataset.hasImage = hasImage ? 'true' : 'false';
  target.shell.dataset.mode = mode === 'cover' ? 'cover' : 'contain';

  if (hasImage) {
    target.bg.src = image;
    target.main.src = image;
    target.bg.classList.remove('hidden');
    target.main.classList.remove('hidden');
    target.main.style.objectFit = target.shell.dataset.mode;
  } else {
    target.bg.removeAttribute('src');
    target.main.removeAttribute('src');
    target.bg.classList.add('hidden');
    target.main.classList.add('hidden');
  }
}

function setHero(image, mode = 'contain') {
  state.heroImage = image || null;
  state.heroMode = mode === 'cover' ? 'cover' : 'contain';
  applyMedia(loginMedia, state.heroImage, state.heroMode);
  applyMedia(panelMedia, state.heroImage, state.heroMode);
  heroModeInput.value = state.heroMode;
}

function showLogin(message = '') {
  appView.classList.add('hidden');
  loginView.classList.remove('hidden');
  setFeedback(loginMessage, message, message ? 'err' : '');
}

function showApp() {
  loginView.classList.add('hidden');
  appView.classList.remove('hidden');
  welcomeUser.textContent = `Usuário: ${state.user || 'admin'}`;
  setPhotoSection(false);
}

function spotlightPhotoSection() {
  heroPanel.classList.remove('pulse-soft');
  void heroPanel.offsetWidth;
  heroPanel.classList.add('pulse-soft');
}

function setPhotoSection(open) {
  const isOpen = Boolean(open);
  heroPanel.classList.toggle('is-open', isOpen);
  heroPanel.setAttribute('aria-hidden', String(!isOpen));
  focusPhotoBtn.textContent = isOpen ? 'Fechar foto de perfil' : 'Colocar foto de perfil';
}

function updateStats(keys) {
  document.getElementById('statTotal').textContent = keys.length;
  document.getElementById('statActive').textContent = keys.filter((item) => item.status === 'active').length;
  document.getElementById('statExpired').textContent = keys.filter((item) => item.status === 'expired').length;
  document.getElementById('statBound').textContent = keys.filter((item) => item.deviceBound).length;
}

function renderKeys(keys) {
  updateStats(keys);

  if (!keys.length) {
    keysList.innerHTML = '<div class="empty-state">Nenhuma key criada ainda.</div>';
    return;
  }

  keysList.innerHTML = keys.map((item) => {
    const statusLabel = item.status === 'active' ? 'ativa' : item.status === 'expired' ? 'expirada' : 'desativada';

    return `
      <article class="key-card">
        <div class="key-head">
          <div class="key-string">${escapeHtml(item.key)}</div>
          <span class="status-badge">${statusLabel}</span>
        </div>

        <div class="key-meta">
          <div class="meta-box"><span>Dono</span><strong>${escapeHtml(item.owner || '-')}</strong></div>
          <div class="meta-box"><span>Dias restantes</span><strong>${item.daysRemaining}</strong></div>
          <div class="meta-box"><span>Criada em</span><strong>${escapeHtml(item.createdAtLabel)}</strong></div>
          <div class="meta-box"><span>Expira em</span><strong>${escapeHtml(item.expiresAtLabel)}</strong></div>
          <div class="meta-box"><span>Aparelho</span><strong>${escapeHtml(item.deviceName || 'Livre')}</strong></div>
          <div class="meta-box"><span>Validações</span><strong>${item.validationCount}</strong></div>
          <div class="meta-box"><span>Primeira validação</span><strong>${escapeHtml(item.firstValidationAtLabel)}</strong></div>
          <div class="meta-box"><span>Observação</span><strong>${escapeHtml(item.note || '-')}</strong></div>
        </div>

        <div class="key-actions">
          <button class="btn btn-ghost" type="button" data-action="copy" data-key="${escapeHtml(item.key)}">Copiar</button>
          <button class="btn btn-main" type="button" data-action="toggle" data-active="${item.active}" data-key="${escapeHtml(item.key)}">${item.active ? 'Desativar' : 'Ativar'}</button>
          <button class="btn btn-ghost" type="button" data-action="extend" data-key="${escapeHtml(item.key)}">+ Dias</button>
          <button class="btn btn-ghost" type="button" data-action="edit" data-key="${escapeHtml(item.key)}">Editar</button>
          <button class="btn btn-ghost" type="button" data-action="reset" data-key="${escapeHtml(item.key)}">Soltar aparelho</button>
          <button class="btn btn-ghost" type="button" data-action="delete" data-key="${escapeHtml(item.key)}">Remover</button>
        </div>
      </article>
    `;
  }).join('');
}

function filterKeys() {
  const query = searchInput.value.trim().toLowerCase();
  if (!query) {
    renderKeys(state.keys);
    return;
  }

  const filtered = state.keys.filter((item) => [item.key, item.owner, item.note, item.deviceName].join(' ').toLowerCase().includes(query));
  renderKeys(filtered);
}

async function loadDashboard() {
  const data = await api('/api/dashboard');
  state.keys = Array.isArray(data.keys) ? data.keys : [];
  renderKeys(state.keys);
}

function openModal(title, content, onSubmit) {
  modalTitle.textContent = title;
  modalForm.innerHTML = content;
  modal.classList.remove('hidden');
  modalForm.onsubmit = async (event) => {
    event.preventDefault();
    await onSubmit(new FormData(modalForm));
  };
}

function closeModal() {
  modal.classList.add('hidden');
  modalForm.innerHTML = '';
  modalForm.onsubmit = null;
}

function askExtend(key) {
  openModal(
    `Aumentar validade - ${key}`,
    `
      <label class="field">
        <span>Adicionar quantos dias?</span>
        <input name="days" type="number" min="1" value="30" required>
      </label>
      <button class="btn btn-main" type="submit">Salvar</button>
    `,
    async (formData) => {
      await api('/api/keys/extend', {
        method: 'POST',
        body: JSON.stringify({ key, days: Number(formData.get('days')) })
      });
      closeModal();
      showToast('Validade aumentada');
      await loadDashboard();
    }
  );
}

function askEdit(key) {
  const item = state.keys.find((entry) => entry.key === key);
  if (!item) return;

  openModal(
    `Editar - ${key}`,
    `
      <label class="field">
        <span>Dono</span>
        <input name="owner" type="text" value="${escapeHtml(item.owner || '')}" placeholder="Nome do dono">
      </label>
      <label class="field">
        <span>Observação</span>
        <input name="note" type="text" value="${escapeHtml(item.note || '')}" placeholder="Detalhe da key">
      </label>
      <button class="btn btn-main" type="submit">Salvar</button>
    `,
    async (formData) => {
      await api('/api/keys/update-owner', {
        method: 'POST',
        body: JSON.stringify({
          key,
          owner: String(formData.get('owner') || ''),
          note: String(formData.get('note') || '')
        })
      });
      closeModal();
      showToast('Key atualizada');
      await loadDashboard();
    }
  );
}

async function handleCardAction(event) {
  const button = event.target.closest('button[data-action]');
  if (!button) return;

  const key = button.dataset.key;
  const action = button.dataset.action;

  try {
    if (action === 'copy') {
      await navigator.clipboard.writeText(key);
      showToast(`Copiada: ${key}`);
      return;
    }

    if (action === 'toggle') {
      const active = button.dataset.active === 'true';
      await api(active ? '/api/keys/disable' : '/api/keys/enable', {
        method: 'POST',
        body: JSON.stringify({ key })
      });
      showToast(active ? 'Key desativada' : 'Key ativada');
      await loadDashboard();
      return;
    }

    if (action === 'extend') return askExtend(key);
    if (action === 'edit') return askEdit(key);

    if (action === 'reset') {
      if (!confirm(`Soltar o aparelho da key ${key}?`)) return;
      await api('/api/keys/reset-device', { method: 'POST', body: JSON.stringify({ key }) });
      showToast('Aparelho removido');
      await loadDashboard();
      return;
    }

    if (action === 'delete') {
      if (!confirm(`Remover a key ${key}?`)) return;
      await api('/api/keys/delete', { method: 'POST', body: JSON.stringify({ key }) });
      showToast('Key removida');
      await loadDashboard();
    }
  } catch (error) {
    showToast(error.message);
  }
}

function readSelectedFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Erro ao ler a imagem'));
    reader.readAsDataURL(file);
  });
}

async function saveHero(removeHero = false) {
  setFeedback(heroMessage, removeHero ? 'Removendo foto...' : 'Salvando visual...');

  try {
    const data = await api('/api/config/update', {
      method: 'POST',
      body: JSON.stringify({
        panelTitle: panelTitleInput.value.trim() || 'SLAYER KEY PANEL',
        heroMode: heroModeInput.value,
        heroImage: removeHero ? null : state.heroFileData,
        removeHero
      })
    });

    setTitle(data.data.panelTitle);
    setHero(data.data.heroImage, data.data.heroMode);
    state.heroFileData = null;
    heroFileInput.value = '';
    setFeedback(heroMessage, removeHero ? 'Foto removida' : 'Visual salvo com sucesso', 'ok');
    showToast(removeHero ? 'Foto removida' : 'Visual salvo');
  } catch (error) {
    setFeedback(heroMessage, error.message, 'err');
  }
}

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  setFeedback(loginMessage, 'Entrando...');

  try {
    const data = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({
        username: document.getElementById('username').value.trim(),
        password: document.getElementById('password').value
      })
    });

    state.user = data.user;
    setTitle(data.panelTitle);
    setHero(data.heroImage, data.heroMode);
    showApp();
    setFeedback(loginMessage, '');
    await loadDashboard();
  } catch (error) {
    showLogin(error.message);
  }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch {}
  showLogin('Saiu da conta');
});

document.getElementById('createBtn').addEventListener('click', async () => {
  setFeedback(createMessage, 'Criando key...');

  try {
    const data = await api('/api/keys/create', {
      method: 'POST',
      body: JSON.stringify({
        days: Number(document.getElementById('createDays').value),
        owner: document.getElementById('createOwner').value.trim(),
        note: document.getElementById('createNote').value.trim()
      })
    });

    setFeedback(createMessage, `Key criada: ${data.data.key}\nDias restantes: ${data.data.daysRemaining}\nCriada em: ${data.data.createdAtLabel}`, 'ok');
    document.getElementById('createOwner').value = '';
    document.getElementById('createNote').value = '';
    await loadDashboard();
  } catch (error) {
    setFeedback(createMessage, error.message, 'err');
  }
});

document.getElementById('validateBtn').addEventListener('click', async () => {
  setFeedback(validateMessage, 'Validando...');

  try {
    const data = await api('/api/keys/validate', {
      method: 'POST',
      body: JSON.stringify({
        key: document.getElementById('validateKey').value.trim(),
        deviceId: document.getElementById('validateDeviceId').value.trim(),
        deviceName: document.getElementById('validateDeviceName').value.trim()
      })
    });

    setFeedback(validateMessage, `${data.message}\nDias restantes: ${data.data.daysRemaining}\nCriada em: ${data.data.createdAtLabel}`, 'ok');
    await loadDashboard();
  } catch (error) {
    setFeedback(validateMessage, error.message, 'err');
  }
});

document.getElementById('saveHeroBtn').addEventListener('click', async () => {
  if (!state.heroFileData && panelTitleInput.value.trim() === state.panelTitle && heroModeInput.value === state.heroMode) {
    setFeedback(heroMessage, 'Nada para salvar');
    return;
  }
  await saveHero(false);
});

document.getElementById('removeHeroBtn').addEventListener('click', async () => {
  await saveHero(true);
});

heroFileInput.addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;

  try {
    const dataUrl = await readSelectedFile(file);
    state.heroFileData = dataUrl;
    setHero(dataUrl, heroModeInput.value);
    setFeedback(heroMessage, 'Foto carregada. Agora toque em salvar foto.', 'ok');
  } catch (error) {
    setFeedback(heroMessage, error.message, 'err');
  }
});

heroModeInput.addEventListener('change', () => {
  setHero(state.heroFileData || state.heroImage, heroModeInput.value);
});

focusPhotoBtn.addEventListener('click', () => {
  const willOpen = !heroPanel.classList.contains('is-open');
  setPhotoSection(willOpen);
  if (willOpen) {
    setTimeout(() => {
      heroPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      spotlightPhotoSection();
    }, 40);
  }
});

document.getElementById('reloadBtn').addEventListener('click', loadDashboard);
searchInput.addEventListener('input', filterKeys);
keysList.addEventListener('click', handleCardAction);
document.getElementById('closeModalBtn').addEventListener('click', closeModal);
modal.addEventListener('click', (event) => {
  if (event.target.dataset.close === 'true') closeModal();
});

async function boot() {
  try {
    const config = await api('/api/config/public');
    setTitle(config.panelTitle);
    setHero(config.heroImage, config.heroMode);
  } catch {}

  try {
    const session = await api('/api/session');
    setTitle(session.panelTitle);
    setHero(session.heroImage, session.heroMode);
    state.user = session.user;

    if (session.loggedIn) {
      showApp();
      await loadDashboard();
    } else {
      showLogin('');
    }
  } catch {
    showLogin('Erro ao carregar o painel');
  }
}

boot();
