SLAYER KEY PANEL V5

Login padrão:
usuário: admin
senha: admin123

Rodar no Termux:
cd /sdcard/slayer-key-panel-v5
npm install
npm start

Abrir:
http://127.0.0.1:8000

Se a porta 8000 já estiver ocupada:
pkill node
npm start
