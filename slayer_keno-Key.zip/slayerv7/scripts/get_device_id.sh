#!/data/data/com.termux/files/usr/bin/bash
settings get secure android_id
